$("#progressMonitors{{prefix}}").empty();
$("#tabContent{{prefix}}").empty();