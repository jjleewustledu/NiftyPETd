{%import "executePythonDisplayMacro.js" as display with context%}

{%call display.executeDisplayfunction()%}
    {%block preRunCommandScript%}{%endblock%}
{%endcall%}
